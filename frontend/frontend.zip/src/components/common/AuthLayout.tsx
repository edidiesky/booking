import { Link } from "react-router-dom";
import { motion } from "framer-motion";
import { CheckCircle2, Circle, Loader2 } from "lucide-react";
import type { StepItem } from "@/types/ui";
// import LazyImage from "./LazyImage";

interface Props {
  children: React.ReactNode;
  leftContent?: React.ReactNode;
  stepLabels?: string[];
  currentStep?: number;
}

function StepChecklist({ steps }: { steps: StepItem[] }) {
  return (
    <div className="flex flex-col gap-1">
      {steps.map((step, i) => (
        <div
          key={i}
          className="flex items-center gap-3 py-2.5 px-3 rounded-[10px] transition-colors"
        >
          {step.status === "done" && (
            <CheckCircle2
              size={18}
              className="shrink-0"
              style={{ color: "var(--color-ink)" }}
            />
          )}
          {step.status === "active" && (
            <Loader2
              size={18}
              className="shrink-0 animate-spin"
              style={{ color: "var(--color-ink)" }}
            />
          )}
          {step.status === "pending" && (
            <Circle
              size={18}
              className="shrink-0"
              style={{ color: "#d1d5db" }}
            />
          )}
          <span
            className="text-xs"
            style={{
              color: step.status === "pending" ? "#9ca3af" : "var(--color-ink)",
              fontWeight: step.status === "active" ? 600 : 400,
              textDecoration: step.status === "done" ? "line-through" : "none",
            }}
          >
            {step.label}
          </span>
        </div>
      ))}
    </div>
  );
}

export default function AuthLayout({
  children,
  leftContent,
  stepLabels,
  currentStep,
}: Props) {
  const resolvedSteps: StepItem[] | null =
    stepLabels && currentStep != null
      ? stepLabels.map((label, i) => ({
          label,
          status:
            i + 1 < currentStep
              ? "done"
              : i + 1 === currentStep
                ? "active"
                : "pending",
        }))
      : null;

  const remaining =
    resolvedSteps?.filter((s) => s.status !== "done").length ?? null;

  return (
    <div className="min-h-screen grid lg:grid-cols-[600px_1fr]">
      <div className="hidden lg:flex flex-col justify-between p-10">
        <div className="flex flex-col gap-6">
          {resolvedSteps ? (
            <>
              <div className="flex flex-col gap-1">
                {leftContent ?? (
                  <>
                    <h3
                      className="text-[22px] bold"
                      style={{
                        color: "var(--color-ink)",
                        letterSpacing: "-0.3px",
                      }}
                    >
                      Create Account
                    </h3>
                    {remaining != null && remaining > 0 && (
                      <p className="text-xs" style={{ color: "#6b7280" }}>
                        {remaining} step{remaining > 1 ? "s" : ""} remaining
                      </p>
                    )}
                  </>
                )}
              </div>
              <StepChecklist steps={resolvedSteps} />
            </>
          ) : (
            (leftContent ?? (
              <div className="flex flex-col gap-4">
                <h3
                  className="text-[28px] bold "
                  style={{ color: "var(--color-ink)", letterSpacing: "-0.5px" }}
                >
                  Book your next stay.
                </h3>
                
                <p
                  className="text-[15px] w-[80%] leading-relaxed"
                  style={{ color: "#6b7280" }}
                >
                  Discover properties, make reservations, and manage your trips
                  all in one place.
                </p>
                {/* <div
                  className="w-full h-[500px] my-10 overflow-hidden rounded-3xl block"
                >
                  <LazyImage src={'/background.jpeg'} alt={'Bukkings Background'} />
                </div> */}
              </div>
            ))
          )}
        </div>
        <p className="text-xs" style={{ color: "#9ca3af" }}>
          © {new Date().getFullYear()} Bukking Platform
        </p>
      </div>

      <div className="flex items-center justify-center p-6 lg:p-29">
        <motion.div
          initial={{ opacity: 0, y: 24 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4 }}
          className="w-full max-w-md"
        >
          <Link
            to="/"
            className="text-xs lg:text-[13px]     mb-8 block lg:hidden"
            style={{ color: "var(--color-ink)" }}
          >
            Booking
          </Link>
          <div className="lg:w-[90%]">{children}</div>
        </motion.div>
      </div>
    </div>
  );
}
