import { TiSocialFacebook } from "react-icons/ti";
import { FaXTwitter } from "react-icons/fa6";
import { FaInstagram } from "react-icons/fa";
import { FaYoutube } from "react-icons/fa";
import { Link } from "react-router-dom";
import ReactHtmlParser from "react-html-parser";
import sanitizeHtml from "sanitize-html";
import { LuPlus, LuMinus } from "react-icons/lu";
export default function ProductShortDescription({
  data,
}: {
  data: {
    name: string;
    description: string;
    price: number;
    size?: [{ name: string; value: string }];
    colors?: [{ name: string; value: string }];
    category?: string[];
  };
}) {
  // const colorList = ["#FBAC07", "#FF2F36", "#DF565C", "#FF6C4A"];

  // const sizeList = ["L", "XL", "M", "S"];

  const sanitizedValue = sanitizeHtml(data?.description, {
        allowedTags: ["p", "b", "i", "u", "a", "ul", "ol", "li", "h1", "h2", "br"],
        allowedAttributes: {
          a: ["href"],
        },
        disallowedTagsMode: "discard",
      });
  return (
    <div className="w-full">
      <div className="w-full flex flex-col gap-1">
        <div className="w-full flex flex-col gap-2  border-b py-4 border-dotted">
          <h3 className="text-3xl">{data?.name}</h3>
          <h5 className="text-xs lg:text-[13px]   space-y-2 ">
            <span className="block">SKU 028 
              {/* {data?.brand} */}
            </span>
            <span className="block">Be the first to leave a review.</span>
          </h5>
          <h3 className="text-3xl lg:text-4xl ">${data?.price}</h3>
        </div>

        <div className="w-full flex flex-col gap-6  border-b py-4 border-dotted">
          {/* timer */}
          <div className="w-full bg-[#FFCE78] p-6 flex flex-col items-center gap-3">
            <span className="text-xs lg:text-[13px]   ">
              Flash Sale
            </span>
            <div className="flex items-center gap-4">
              {/* Days */}
              <span className="text-xs lg:text-[13px]   ">0 0 Days</span>
              <span className="text-xs lg:text-[13px]   ">0 0 HRS</span>
              <span className="text-xs lg:text-[13px]   ">0 0 Min</span>
              <span className="text-xs lg:text-[13px]   ">0 0 Sec</span>
            </div>
          </div>

          {/* color */}
          <div className="w-full flex items-center gap-8">
            <h3 className="text-xs lg:text-[13px]   ">Color</h3>
            <div className="flex items-center  gap-4">
              {data?.colors?.map((data, index) => {
                return (
                  <div key={index} className="w-14 cursor-pointer hover:bg-[#eee] h-14 rounded-full p-1 border">
                    <div
                      style={{
                        background: `${data?.value}`,
                      }}
                      className="w-full h-full rounded-full"
                    ></div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* size */}
          <div className="w-full flex items-center gap-8">
            <h3 className="text-xs lg:text-[13px]   ">Size</h3>
            <div className="flex items-center  gap-4">
              {data?.size?.map((data, index) => {
                return (
                  <div
                    key={index}
                    className="w-16 cursor-pointer hover:bg-[#eee] flex items-center justify-center h-12 rounded-md text-xs lg:text-[13px]   p-1 border"
                  >
                    {data?.value}
                  </div>
                );
              })}
            </div>
          </div>

          {/* cart button */}
          <div className="w-full py-3 flex items-center gap-4">
            <div className="w-[180px] h-[45px] flex items-center border rounded-full overflow-hidden">
              <div className="w-[50px] border-r h-full flex items-center justify-center text-xs">
                <LuPlus />
              </div>
              <div className="flex-1 h-full flex items-center justify-center text-xs">
                1
              </div>
              <div className="w-[50px] border-l h-full flex items-center justify-center text-xs">
                <LuMinus />
              </div>
            </div>
            <div className="btn btn_small flex-1 text-xs lg:text-[13px]   text-white">
              <span className="p-1">Add to Cart</span>
            </div>
          </div>
        </div>
        {/* description */}
        <div className="w-full flex flex-col gap-2  border-b py-4 border-dotted">
          <p className="text-xs lg:text-[13px]   ">
           {ReactHtmlParser(sanitizedValue)}
          </p>
          <div className="flex items-center justify-end">
            <Link
              to={"cart/36364374"}
              className="p-3 rounded-full text-lg hover:bg-[#FAF8F5]"
            >
              <TiSocialFacebook />
            </Link>
            <Link
              to={"cart/36364374"}
              className="p-3 rounded-full text-xs lg:text-[13px]     hover:bg-[#FAF8F5]"
            >
              <FaXTwitter />
            </Link>
            <Link
              to={"cart/36364374"}
              className="p-3 rounded-full text-xs lg:text-[13px]     hover:bg-[#FAF8F5]"
            >
              <FaInstagram />
            </Link>
            <Link
              to={"cart/36364374"}
              className="p-3 rounded-full text-xs lg:text-[13px]     hover:bg-[#FAF8F5]"
            >
              <FaYoutube />
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}
