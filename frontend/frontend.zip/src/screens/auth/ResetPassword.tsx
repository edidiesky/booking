import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod/v4";
import { Link } from "react-router-dom";
import { Mail } from "lucide-react";
import AuthLayout from "./shared/AuthLayout";
import { Input } from "@/components/ui/input";
import toast from "react-hot-toast";
import React from "react";
import { useRequestPasswordResetMutation } from "@/redux/services/authApi";

const schema = z.object({
  email: z.string().email("Enter a valid email address"),
});

type FormData = z.infer<typeof schema>;

export default function ResetPassword() {
  const [sent, setSent] = React.useState(false);
  const [submittedEmail, setSubmittedEmail] = React.useState("");
  const [requestReset, { isLoading }] = useRequestPasswordResetMutation();

  const { register, handleSubmit, formState: { errors } } = useForm<FormData>({
    resolver: zodResolver(schema),
  });

  const onSubmit = async (data: FormData) => {
    try {
      await requestReset({ email: data.email }).unwrap();
      setSubmittedEmail(data.email);
      setSent(true);
    } catch (err: unknown) {
      const error = err as { data?: { error?: string[] }; error?: string };
      (error?.data?.error ?? [error?.error ?? "Unknown error"]).forEach((m) => toast.error(m));
    }
  };

  if (sent) {
    return (
      <AuthLayout>
        <div className="flex flex-col gap-6 w-[90%]">
          <div className="flex flex-col gap-3">
            <div
              className="w-12 h-12 flex items-center justify-center"
              style={{ backgroundColor: "var(--color-warm-mist)" }}
            >
              <Mail size={20} style={{ color: "var(--color-terracotta)" }} />
            </div>
            <h1
              className="text-[32px]  "
              style={{ color: "var(--color-ink)", letterSpacing: "-0.66px" }}
            >
              Check your inbox
            </h1>
            <p className="text-sm lg:text-sm" style={{ color: "var(--color-muted-stone)" }}>
              If the email {" "}
              <span className="font-bold" style={{ color: "var(--color-ink)" }}>
                {submittedEmail}
              </span> exists, we will send a password reset link to it
              . The link expires in 15 minutes.
            </p>
          </div>

          <div
            className="p-4 flex flex-col gap-2"
            style={{ backgroundColor: "var(--color-fog)" }}
          >
            <p className="text-sm lg:text-[13px]     uppercase " style={{ color: "var(--color-muted-stone)" }}>
              Didn't receive it?
            </p>
            <p className="text-sm" style={{ color: "var(--color-muted-stone)" }}>
              Check your spam folder or{" "}
              <button
                onClick={() => setSent(false)}
                className=" underline underline-offset-4 transition-opacity hover:opacity-60"
                style={{ color: "var(--color-ink)" }}
              >
                try a different email address
              </button>
            </p>
          </div>

          <Link
            to="/login"
            className="text-xs lg:text-[13px]   transition-opacity hover:opacity-60"
            style={{ color: "var(--color-muted-stone)" }}
          >
            Back to sign in
          </Link>
        </div>
      </AuthLayout>
    );
  }

  return (
    <AuthLayout>
      <form onSubmit={handleSubmit(onSubmit)} className="flex flex-col gap-8 w-[90%]">
        <div className="flex flex-col gap-3">
          <h1
            className="text-[32px]  "
            style={{ color: "var(--color-ink)", letterSpacing: "-0.66px" }}
          >
            Reset your password
          </h1>
          <p className="text-xs" style={{ color: "var(--color-muted-stone)" }}>
            Enter the email address linked to your account and we'll send you a reset link.
          </p>
        </div>

        <Input
          label="Email address"
          type="email"
          placeholder="you@example.com"
          icon={<Mail size={15} />}
          error={errors.email?.message}
          {...register("email")}
        />

        <button
          type="submit"
          disabled={isLoading}
          className="w-full h-12 rounded-full flex items-center justify-center gap-2 text-xs lg:text-[13px]     transition-opacity hover:opacity-90 disabled:opacity-50"
          style={{
              backgroundColor: "var(--color-vivid)",
              color: "var(--color-vivid-foreground)",
            }}
        >
          {isLoading ? "Sending..." : "Send reset link"}
        </button>

        <p className="text-xs lg:text-[13px]     text-center" style={{ color: "var(--color-muted-stone)" }}>
          Remember your password?{" "}
          <Link
            to="/login"
            className=" underline underline-offset-4"
            style={{ color: "var(--color-ink)" }}
          >
            Sign in
          </Link>
        </p>
      </form>
    </AuthLayout>
  );
}