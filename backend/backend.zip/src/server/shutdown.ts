import http from "http";

import { disconnectDB } from "@booking/shared";
import redisClient from "../config/redis";
import { disconnectRabbitMQ } from "../messaging/connection";
import { stopOutboxPoller } from "../messaging/outboxPoller";
import { stopWebhookRetryWorker } from "../messaging/workers/webhookRetryWorker";
// import { stopSocketServer }      from "../realtime/socketServer";
import { serverHealthGauge } from "../utils/metrics";
import logger from "../utils/logger";

import {
  lockSweepScheduler,
  reconciliationScheduler,
  campaignScheduler,
  stopBookingExpiryScheduler,
  stopBookingExpiryReconciliation,
  presenceSubscriber,
} from "./bootstrap";
import { stopSocketServer } from "../realtime/socketServer";
import { featureFlagSubscriber } from "./bootstrap";
export function registerShutdownHooks(server: http.Server): void {
  const shutdown = async (signal: string): Promise<void> => {
    logger.info("shutdown_initiated", { event: "shutdown_initiated", signal });
    serverHealthGauge.set(0);

    server.close(async () => {
      try {
        await stopSocketServer();
        stopOutboxPoller();
        stopWebhookRetryWorker();

        lockSweepScheduler.stop();
        reconciliationScheduler.stop();
        campaignScheduler.stop();
        stopBookingExpiryScheduler();
        stopBookingExpiryReconciliation();

        await disconnectRabbitMQ();
        await disconnectDB();
        try {
          if (featureFlagSubscriber) {
            await featureFlagSubscriber.unsubscribe();
            await featureFlagSubscriber.quit();
          }
        } catch (err) {
          logger.warn("feature_flag_subscriber_shutdown_error", {
            event: "feature_flag_subscriber_shutdown_error",
            error: (err as Error).message,
          });
        }

        if (presenceSubscriber) {
          try {
            await presenceSubscriber.unsubscribe();
            await presenceSubscriber.quit();
          } catch (err) {
            logger.warn("presence_subscriber_shutdown_error", {
              event: "presence_subscriber_shutdown_error",
              error: (err as Error).message,
            });
          }
        }

        await redisClient.quit();
        await redisClient.quit();
        logger.info("shutdown_complete", { event: "shutdown_complete" });
        process.exit(0);
      } catch (err) {
        logger.error("shutdown_error", {
          event: "shutdown_error",
          error: (err as Error).message,
        });
        process.exit(1);
      }
    });

    setTimeout(() => process.exit(1), 15_000);
  };

  process.on("SIGTERM", () => void shutdown("SIGTERM"));
  process.on("SIGINT", () => void shutdown("SIGINT"));
}
