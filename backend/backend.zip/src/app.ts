import "./utils/otel";
import "dotenv/config";
import express from "express";
import helmet from "helmet";
import cors from "cors";
import cookieParser from "cookie-parser";
import morgan from "morgan";

import {
  contextMiddleware,
  tenantMiddleware,
} from "./middleware/contextMiddleware";
import { rlsMiddleware } from "./middleware/rlsMiddleware";
import { NotFound, errorHandler } from "./middleware/error-handler";
import { bookingRegistry } from "./utils/metrics";
import authRoutes from "./domains/auth/auth.routes";
import tenantRoutes from "./domains/tenant/tenant.routes";
import propertyRoutes from "./domains/property/property.routes";
import bookingRoutes from "./domains/booking/booking.routes";
import paymentRoutes from "./domains/payment/payment.routes";
import webhookRoutes from "./domains/webhook/webhook.routes";
import escrowRoutes from "./domains/escrow/escrow.routes";
import profileRoutes from "./domains/profile/profile.routes";
import auditRoutes from "./domains/audit/audit.routes";
import auditEventRoutes from "./domains/audit/auditEvent.routes";
import adminRoutes from "./domains/admin/admin.routes";
import sseRouter from "./domains/sse/sse.routes";
import roleRoutes from "./domains/role/role.routes";
import permissionRoutes from "./domains/permission/permission.routes";
import renterRoutes from "./domains/renter/renter.routes";
import securityRoutes from "./domains/security/security.routes";
import reviewRoutes from "./domains/review/review.routes";
import invoiceRoutes from "./domains/invoice/invoice.routes";
import sellerNotificationRoutes from "./domains/seller-notification/seller-notification.routes";
import campaignRoutes from "./domains/campaign/campaign.routes";
import userNotificationRoutes from "./domains/user-notification/user-notification.routes";
import favoriteRoutes from "./domains/favorite/favorite.routes";
import jobRoutes from "./domains/jobs/job.routes";
import invitationRoutes from "./domains/invitation/invitation.routes";
import sessionRoutes from "./domains/session/session.routes";
import redisClient from "./config/redis";
import { logger, query } from "@booking/shared";
import propertySearchRoutes from "./domains/property-search/propertySearch.routes";
import conversationRoutes from "./domains/conversation/conversation.routes";
import messageRoutes from "./domains/message/message.routes";
import { createFeatureFlagRouter } from "./domains/feature-flags/feature-flags.routes";
import { FeatureFlagRepository } from "./domains/feature-flags/featureFlag.repository";
import { getFeatureFlagEngine } from "./domains/feature-flags/FeatureFlagEngine";
// import discoveryRoutes from "./domains/property-search/discovery.routes";
const app = express();

if (!process.env.WEB_ORIGIN) throw new Error("WEB_ORIGIN env var not set.");
const PLATFORM_DOMAIN = process.env.PLATFORM_DOMAIN ?? "bukkings.space";
const WEB_ORIGIN = process.env.WEB_ORIGIN;

app.use(helmet());
app.use(
  cors({
    origin: (origin, callback) => {
      if (!origin) return callback(null, true);
      if (origin === WEB_ORIGIN) return callback(null, true);
      try {
        const hostname = new URL(origin).hostname;
        if (hostname.endsWith(`.${PLATFORM_DOMAIN}`))
          return callback(null, true);
      } catch {}
      callback(new Error(`Origin ${origin} not allowed`));
    },
    credentials: true,
  }),
);
app.use(morgan("dev"));
app.use(cookieParser());
app.use(express.json({ limit: "10mb" }));
app.use(express.urlencoded({ extended: true }));
app.use(contextMiddleware);
app.set("trust proxy", 1);

// Health
app.get("/health", async (_req, res) => {
  let checks: Record<string, boolean> = {};
  try {
    await redisClient.ping();
    checks.redis = true;
  } catch (error) {
    checks.redis = false;
  }

  try {
    await query("SELECT 1");
    checks.postgres = true;
  } catch (error) {
    checks.postgres = false;
  }
  const healthy = Object.values(checks).every(Boolean);
  logger.info("Health Checks:", {
    event: "booking_health_check_event",
    checks,
  });
  res.json({
    status: healthy ? "ok" : "Degraded",
    service: "booking-platform",
    ts: new Date().toISOString(),
  });
});

// Prometheus metrics
app.get("/metrics", async (_req, res) => {
  res.set("Content-Type", bookingRegistry.contentType);
  res.end(await bookingRegistry.metrics());
});

app.use("/api/v1/auth", authRoutes);
app.use("/api/v1/webhooks", webhookRoutes);

// Tenant-scoped routes
app.use("/api/v1/renters", tenantMiddleware, rlsMiddleware, renterRoutes);
app.use("/api/v1/sse", tenantMiddleware, rlsMiddleware, sseRouter);
app.use("/api/v1/tenants", tenantMiddleware, rlsMiddleware, tenantRoutes);
app.use("/api/v1/properties", tenantMiddleware, rlsMiddleware, propertyRoutes);
app.use("/api/v1/properties-search", propertySearchRoutes);
// app.use("/api/v1/properties-discovery", discoveryRoutes);
app.use("/api/v1/bookings", tenantMiddleware, rlsMiddleware, bookingRoutes);
app.use("/api/v1/payments", tenantMiddleware, rlsMiddleware, paymentRoutes);
app.use("/api/v1/escrow", tenantMiddleware, rlsMiddleware, escrowRoutes);
app.use("/api/v1/profile", profileRoutes);
app.use("/api/v1/security", securityRoutes); 
app.use("/api/v1/sessions", sessionRoutes); 
app.use("/api/v1/audit", tenantMiddleware, auditRoutes);
app.use(
  "/api/v1/audit-events",
  tenantMiddleware,
  rlsMiddleware,
  auditEventRoutes,
);
app.use("/api/v1/roles", tenantMiddleware, roleRoutes);
app.use("/api/v1/permissions", tenantMiddleware, permissionRoutes);
app.use("/api/v1/reviews", reviewRoutes);
app.use("/api/v1/invoices", invoiceRoutes);
app.use("/api/v1/seller-notifications", sellerNotificationRoutes);
app.use("/api/v1/campaigns", campaignRoutes);
app.use("/api/v1/user-notifications", userNotificationRoutes);
app.use("/api/v1/favorites", favoriteRoutes);
app.use("/api/v1/jobs", jobRoutes);
app.use("/api/v1/invitations", invitationRoutes);
app.use("/api/v1/admin", adminRoutes);
app.use(
  "/api/v1/conversations",
  tenantMiddleware,
  rlsMiddleware,
  conversationRoutes,
);
app.use(
  "/api/v1/conversations",
  tenantMiddleware,
  rlsMiddleware,
  messageRoutes,
);
app.use("/api/v1/admin/feature-flags", (req, res, next) => {
  // Lazy bind so import order stays safe: engine exists only after bootstrap
  const router = createFeatureFlagRouter(
    new FeatureFlagRepository(redisClient),
    getFeatureFlagEngine(),
  );
  return router(req, res, next);
});
// adminRoutes

app.use(NotFound);
app.use(errorHandler);

export { app };
