import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";
import Joi from "joi";
import { nanoid } from "nanoid";
import { v4 as uuid } from "uuid";
import redisClient from "../../config/redis";
import { userRepository } from "./auth.repository";
import { profileRepository } from "../profile/profile.repository";
import { tenantRepository } from "../tenant/tenant.repository";
import { auditRepository } from "../audit/audit.repository";
import { AppError } from "../../utils/AppError";
import logger from "../../utils/logger";
import { requestContext } from "../../context/requestContext";
import { JWTPayload, UserType } from "../../types";
import { withTransaction } from "@booking/shared";
import {
  publishNotifyAuthOtp,
  publishNotifyAuthPasswordRequestResetPayload,
  publishNotifyAuthRegistered,
} from "../../messaging/publisher";
import { authenticator } from "otplib";
import QRCode from "qrcode";
import { OAuth2Client } from "google-auth-library";
import { auditEventRepository } from "../audit/auditEvent.repository";
import { roleRepository } from "../role/role.repository";
import { userRoleRepository } from "../user-role/user-role.repository";
import { tenantService } from "../tenant/tenant.service";
import { sessionVersionRepository } from "./sessionVersion.repository";
import { sessionRepository } from "../session/session.repository";
import { idleTrackingRepository } from "./idleTracking.repository";
import { instrumentService } from "../../utils/instrumentService";
import { measureAuthOp } from "../../utils/metrics";

const googleClient = new OAuth2Client(
  process.env.GOOGLE_CLIENT_ID,
  process.env.GOOGLE_CLIENT_SECRET,
  process.env.GOOGLE_REDIRECT_URI,
);

const TWO_FACTOR_CHALLENGE_TTL_SEC = 5 * 60;
const twoFactorChallengeKey = (token: string) => `2fa-challenge:${token}`;

const JWT_EXPIRY_SEC = 15 * 60;
const REFRESH_EXPIRY_SEC = 7 * 24 * 60 * 60;
const ONBOARDING_TTL_SEC = 60 * 60;
const PASSWORD_RESET_TTL_SEC = 15 * 60;

const onboardingKey = (email: string) => `onboarding:${email}`;
const refreshKey = (token: string) => `refresh:${token}`;
const blocklistKey = (userId: string) => `blocklist:${userId}`;
const passwordResetKey = (token: string) => `password-reset:${token}`;

interface OnboardingState {
  step: "email_sent" | "email_verified" | "complete";
  passwordHash: string;
  token?: string;
  tokenExpiresAt?: number;
}

export type SessionDeviceMeta = {
  deviceLabel: string;
  deviceType: "desktop" | "mobile" | "tablet" | "unknown";
  os: string | null;
  browser: string | null;
  ipAddress: string;
  city: string | null;
  country: string | null;
};

function signAccessToken(
  payload: JWTPayload,
  sessionId: string,
  sessionVersion: number,
): string {
  return jwt.sign(
    { user: payload, sessionId, sessionVersion },
    process.env.JWT_SECRET!,
    {
      expiresIn: JWT_EXPIRY_SEC,
      issuer: "booking-platform",
      audience: "booking-client",
    },
  );
}

export interface InitiateOnboardingInput {
  email: string;
  password: string;
}

export interface ConfirmEmailInput {
  email: string;
  token: string;
}

export interface RegisterGuestInput {
  email: string;
  firstName: string;
  lastName: string;
  phone?: string;
}

export interface RegisterHostInput extends RegisterGuestInput {
  tenantName: string;
  tenantSlug: string;
  platformFeePct?: number;
}

export interface LoginInput {
  email: string;
  password: string;
}

export interface AuthTokens {
  accessToken: string;
  refreshToken: string;
  user: {
    id: string;
    firstName?: string;
    lastName?: string;
    userType: UserType;
    tenantId?: string;
  };
}

export class AuthService {
  async initiateOnboarding(
    input: InitiateOnboardingInput,
  ): Promise<{ message: string; debug?: string }> {
    const email = input.email.toLowerCase().trim();

    if (await userRepository.emailExists(email)) {
      throw AppError.conflict("An account with this email already exists.");
    }

    const passwordHash = await bcrypt.hash(input.password, 12);
    const token = Math.floor(100_000 + Math.random() * 900_000).toString();

    const state: OnboardingState = {
      step: "email_sent",
      passwordHash,
      token,
      tokenExpiresAt: Date.now() + 15 * 60 * 1_000,
    };

    await redisClient.set(
      onboardingKey(email),
      JSON.stringify(state),
      "EX",
      ONBOARDING_TTL_SEC,
    );

    logger.info("onboarding_initiated", {
      event: "onboarding_initiated",
      email,
      requestId: requestContext.get()?.requestId,
    });

    // Fire-and-forget: publish OTP notification
    // Promise.allSettled ensures a publish failure never breaks registration
    void Promise.allSettled([
      publishNotifyAuthOtp({
        notificationId: uuid(),
        email,
        firstName: email.split("@")[0], // best guess before we have a name
        otp: token,
      }),
    ]);

    const isDev = process.env.NODE_ENV !== "production";
    return {
      message: "OTP sent to your email. Please verify to continue.",
      ...(isDev ? { debug: token } : {}),
    };
  }

  async confirmEmail(input: ConfirmEmailInput): Promise<void> {
    const email = input.email.toLowerCase().trim();
    const raw = await redisClient.get(onboardingKey(email));

    if (!raw)
      throw AppError.badRequest("No onboarding session found. Please restart.");

    const state = JSON.parse(raw) as OnboardingState;

    if (state.token !== input.token) {
      throw AppError.badRequest("The OTP provided is not valid.");
    }
    if (Date.now() > (state.tokenExpiresAt ?? 0)) {
      throw AppError.badRequest(
        "OTP has expired. Please restart the registration.",
      );
    }

    state.step = "email_verified";
    await redisClient.set(
      onboardingKey(email),
      JSON.stringify(state),
      "EX",
      ONBOARDING_TTL_SEC,
    );

    logger.info("email_confirmed", {
      event: "email_confirmed",
      email,
      requestId: requestContext.get()?.requestId,
    });
  }

  async registerGuest(
    input: RegisterGuestInput,
    device?: SessionDeviceMeta,
  ): Promise<AuthTokens> {
    const email = input.email.toLowerCase().trim();
    const raw = await redisClient.get(onboardingKey(email));

    if (!raw)
      throw AppError.badRequest(
        "Please verify your email before completing registration.",
      );

    const state = JSON.parse(raw) as OnboardingState;
    if (state.step !== "email_verified") {
      throw AppError.badRequest(
        "Please verify your email before completing registration.",
      );
    }

    const { passwordHash } = state;
    let userId!: string;

    await withTransaction(async (client) => {
      if (await userRepository.emailExists(email)) {
        throw AppError.conflict("An account with this email already exists.");
      }

      const user = await userRepository.create(
        {
          email,
          passwordHash,
          userType: "guest",
          firstName: input.firstName,
          lastName: input.lastName,
          phone: input.phone,
        },
        client,
      );
      userId = user.id;

      await userRepository.updateById(
        userId,
        { status: "active", is_email_verified: true },
        client,
      );
      await profileRepository.create(
        { userId, displayName: `${input.firstName} ${input.lastName}`.trim() },
        client,
      );
      const guestRole = await roleRepository.findBySlug("guest");
      if (!guestRole) {
        throw AppError.internal(
          "guest system role is not seeded. Registration cannot proceed.",
        );
      }
      await userRoleRepository.assign(
        {
          userId,
          tenantId: null,
          roleId: guestRole.id,
          assignedBy: userId,
          reason: "Initial registration",
        },
        client,
      );
    });

    await redisClient.del(onboardingKey(email));
    await auditRepository.log({
      action: "created",
      resource: "user",
      resourceId: userId,
      userId,
    });

    // Publish welcome notification after successful registration
    void Promise.allSettled([
      publishNotifyAuthRegistered({
        notificationId: uuid(),
        email,
        firstName: input.firstName,
        lastName: input.lastName,
        userType: "guest",
      }),
    ]);

    logger.info("guest_registered", {
      event: "guest_registered",
      userId,
      requestId: requestContext.get()?.requestId,
    });

    return this._buildTokens(
      userId,
      "guest",
      `${input.firstName} ${input.lastName}`,
      undefined,
      device,
    );
  }

  async registerHost(
    input: RegisterHostInput,
    device?: SessionDeviceMeta,
  ): Promise<AuthTokens> {
    const email = input.email.toLowerCase().trim();
    const raw = await redisClient.get(onboardingKey(email));

    if (!raw)
      throw AppError.badRequest(
        "Please verify your email before completing registration.",
      );

    const state = JSON.parse(raw) as OnboardingState;
    if (state.step !== "email_verified") {
      throw AppError.badRequest(
        "Please verify your email before completing registration.",
      );
    }

    if (await tenantRepository.slugExists(input.tenantSlug)) {
      throw AppError.conflict(
        "This business URL is already taken. Please choose another.",
      );
    }

    const { passwordHash } = state;
    let userId!: string;
    let tenantId!: string;

    await withTransaction(async (client) => {
      if (await userRepository.emailExists(email))
        throw AppError.conflict("Email already registered.");

      const user = await userRepository.create(
        {
          email,
          passwordHash,
          userType: "host:admin",
          firstName: input.firstName,
          lastName: input.lastName,
          phone: input.phone,
        },
        client,
      );
      userId = user.id;

      const tenant = await tenantRepository.create(
        {
          slug: input.tenantSlug,
          name: input.tenantName,
          ownerUserId: userId,
          platformFeePct: input.platformFeePct ?? 10.0,
        },
        client,
      );
      tenantId = tenant.id;

      await userRepository.updateById(
        userId,
        { status: "active", is_email_verified: true, tenant_id: tenantId },
        client,
      );
      await profileRepository.create(
        { userId, displayName: `${input.firstName} ${input.lastName}`.trim() },
        client,
      );
      const hostRole = await roleRepository.findBySlug("host:admin");
      if (!hostRole) {
        throw AppError.internal(
          "host:admin system role is not seeded. Registration cannot proceed.",
        );
      }

      const subdomainCandidate = await tenantService.resolveAndClaimSubdomain(
        tenantId,
        input.tenantSlug,
        client,
      );

      await userRoleRepository.assign(
        {
          userId,
          tenantId,
          roleId: hostRole.id,
          assignedBy: userId,
          reason: "Initial registration",
        },
        client,
      );

      await auditEventRepository.record(
        {
          tenantId,
          actor: {
            type: "user",
            id: userId,
            email,
            name: `${input.firstName} ${input.lastName}`.trim(),
          },
          action: "tenant.registered",
          targetType: "tenant",
          targetId: tenantId,
          after: { subdomain: subdomainCandidate },
          outcome: "allowed",
          requestId: requestContext.get()?.requestId,
        },
        client,
      );
    });

    await redisClient.del(onboardingKey(email));
    await auditRepository.log({
      action: "created",
      resource: "tenant",
      resourceId: tenantId,
      userId,
    });

    void Promise.allSettled([
      publishNotifyAuthRegistered({
        notificationId: uuid(),
        email,
        firstName: input.firstName,
        lastName: input.lastName,
        userType: "host:admin",
        tenantName: input.tenantName,
        tenantSlug: input.tenantSlug,
      }),
    ]);

    logger.info("host_registered", {
      event: "host_registered",
      userId,
      tenantId,
      requestId: requestContext.get()?.requestId,
    });

    return this._buildTokens(
      userId,
      "host:admin",
      `${input.firstName} ${input.lastName}`,
      tenantId,
      device,
    );
  }

  async refreshToken(
    token: string,
  ): Promise<{ accessToken: string; refreshToken: string }> {
    const raw = await redisClient.get(refreshKey(token));
    if (!raw) throw AppError.unauthorized("Invalid or expired refresh token.");

    const data = JSON.parse(raw) as {
      userId: string;
      userType: UserType;
      name: string;
      tenantId?: string;
      sessionId?: string;
    };

    if (!data.sessionId) {
      // Force re-login for pre-session refresh tokens
      await redisClient.del(refreshKey(token));
      throw AppError.unauthorized("Session expired. Please log in again.");
    }

    const session = await sessionRepository.findById(data.sessionId);
    if (!session || session.revoked_at) {
      await redisClient.del(refreshKey(token));
      throw AppError.unauthorized("Session expired. Please log in again.");
    }

    const active = await idleTrackingRepository.touchIfActive(data.sessionId);
    if (!active) {
      await sessionRepository.revoke(data.sessionId, "user_logout");
      await redisClient.del(refreshKey(token));
      throw AppError.unauthorized(
        "Session expired due to inactivity. Please log in again.",
      );
    }

    const sessionVersion = await sessionVersionRepository.get(data.userId);
    const accessToken = signAccessToken(
      {
        userId: data.userId,
        userType: data.userType,
        name: data.name,
        tenantId: data.tenantId,
      },
      data.sessionId,
      sessionVersion,
    );

    await redisClient.del(refreshKey(token));
    const newRefreshToken = nanoid(32);
    await redisClient.set(
      refreshKey(newRefreshToken),
      JSON.stringify(data),
      "EX",
      REFRESH_EXPIRY_SEC,
    );

    return { accessToken, refreshToken: newRefreshToken };
  }
  async logout(
    userId: string,
    accessToken: string,
    refreshToken?: string,
    sessionId?: string,
  ): Promise<void> {
    let ttl = JWT_EXPIRY_SEC;

    try {
      const decoded = jwt.decode(accessToken) as {
        exp?: number;
        sessionId?: string;
      } | null;

      if (decoded?.exp) {
        ttl = Math.max(0, decoded.exp - Math.floor(Date.now() / 1000));
      }
      if (!sessionId && decoded?.sessionId) {
        sessionId = decoded.sessionId;
      }
    } catch {
      /* ignore decode errors */
    }

    if (sessionId) {
      await sessionRepository.revoke(sessionId, "user_logout");
    }

    await sessionVersionRepository.bump(userId);
    await redisClient.set(
      blocklistKey(userId),
      "1",
      "EX",
      Math.min(ttl || JWT_EXPIRY_SEC, JWT_EXPIRY_SEC),
    );
    if (refreshToken) {
      await redisClient.del(refreshKey(refreshToken));
    }

    await auditRepository.log({
      action: "logout",
      resource: "user",
      resourceId: userId,
      userId,
      newValue: { sessionId: sessionId ?? null },
    });

    logger.info("user_logged_out", {
      event: "user_logged_out",
      userId,
      sessionId,
      requestId: requestContext.get()?.requestId,
    });
  }

  async resendOtp(email: string): Promise<{ message: string; debug?: string }> {
    const normalised = email.toLowerCase().trim();
    const raw = await redisClient.get(onboardingKey(normalised));
    if (!raw)
      throw AppError.badRequest(
        "No onboarding session found. Please restart registration.",
      );

    const state = JSON.parse(raw) as OnboardingState;
    const token = Math.floor(100_000 + Math.random() * 900_000).toString();

    state.token = token;
    state.tokenExpiresAt = Date.now() + 15 * 60 * 1_000;

    await redisClient.set(
      onboardingKey(normalised),
      JSON.stringify(state),
      "EX",
      ONBOARDING_TTL_SEC,
    );

    // Re-publish OTP notification
    void Promise.allSettled([
      publishNotifyAuthOtp({
        notificationId: uuid(),
        email: normalised,
        firstName: normalised.split("@")[0],
        otp: token,
      }),
    ]);

    logger.info("otp_resent", {
      event: "otp_resent",
      email: normalised,
      requestId: requestContext.get()?.requestId,
    });

    const isDev = process.env.NODE_ENV !== "production";
    return {
      message: "New OTP sent to your email.",
      ...(isDev ? { debug: token } : {}),
    };
  }

  async _buildTokens(
    userId: string,
    userType: UserType,
    name: string,
    tenantId: string | undefined,
    device?: SessionDeviceMeta,
  ): Promise<AuthTokens> {
    const session = await sessionRepository.create({
      userId,
      deviceLabel: device?.deviceLabel ?? "Unknown device",
      deviceType: device?.deviceType ?? "unknown",
      os: device?.os ?? null,
      browser: device?.browser ?? null,
      ipAddress: device?.ipAddress ?? "0.0.0.0",
      city: device?.city ?? null,
      country: device?.country ?? null,
    });

    await idleTrackingRepository.start(session.id);
    await redisClient.del(blocklistKey(userId));

    const sessionVersion = await sessionVersionRepository.get(userId);
    const accessToken = signAccessToken(
      { userId, userType, name, tenantId },
      session.id,
      sessionVersion,
    );

    const refreshToken = nanoid(32);
    await redisClient.set(
      refreshKey(refreshToken),
      JSON.stringify({
        userId,
        userType,
        name,
        tenantId,
        sessionId: session.id,
      }),
      "EX",
      REFRESH_EXPIRY_SEC,
    );

    const user = await userRepository.findById(userId);

    return {
      accessToken,
      refreshToken,
      user: {
        id: userId,
        firstName: user?.first_name,
        lastName: user?.last_name,
        userType,
        tenantId,
      },
    };
  }

  async changePassword(userId: string, body: unknown) {
    const schema = Joi.object({
      currentPassword: Joi.string().required(),
      newPassword: Joi.string().min(8).required(),
    });
    const { error, value } = schema.validate(body, { abortEarly: false });
    if (error) throw AppError.badRequest(error.details[0].message);
    const { currentPassword, newPassword } = value as {
      currentPassword: string;
      newPassword: string;
    };

    const user = await userRepository.findByIdWithSecrets(userId);
    if (!user) throw AppError.notFound("User.");
    if (!(await bcrypt.compare(currentPassword, user.password_hash))) {
      throw AppError.unauthorized("Current password is incorrect.");
    }

    const newHash = await bcrypt.hash(newPassword, 12);
    await userRepository.updatePasswordHash(userId, newHash);

    await auditRepository.log({
      action: "updated",
      resource: "password",
      resourceId: userId,
      userId,
    });

    logger.info("password_changed", { event: "password_changed", userId });
    return { message: "Password changed." };
  }

  // request password reset
  async requestPasswordReset(email: string) {
    const schema = Joi.object({ email: Joi.string().email().required() });
    const { error, value } = schema.validate({ email });
    if (error) throw AppError.badRequest(error.details[0].message);

    const user = await userRepository.findByEmail(value.email as string);
    if (!user) {
      logger.info("password_reset_requested_unknown_email", {
        event: "password_reset_requested_unknown_email",
      });
      return {
        message: "If that email is registered, a reset link has been sent.",
      };
    }
    const token = nanoid(32);
    await redisClient.set(
      passwordResetKey(token),
      user.id,
      "EX",
      PASSWORD_RESET_TTL_SEC,
    );
    // authPasswordRequestResetTemplate

    const resetUrl = `${process.env.WEB_ORIGIN}/reset-password/${token}`;
    void Promise.allSettled([
      publishNotifyAuthPasswordRequestResetPayload({
        notificationId: uuid(),
        email: user.email,
        firstName: user.first_name,
        resetUrl,
      }),
    ]);

    logger.info("password_reset_requested", {
      event: "password_reset_requested",
      userId: user.id,
    });
    return {
      message: "If that email is registered, a reset link has been sent.",
    };
  }

  async confirmPasswordReset(body: unknown) {
    const schema = Joi.object({
      token: Joi.string().required(),
      password: Joi.string().min(8).required(),
    });
    const { error, value } = schema.validate(body, { abortEarly: false });
    if (error) throw AppError.badRequest(error.details[0].message);
    const { token, password } = value as { token: string; password: string };

    const userId = await redisClient.get(passwordResetKey(token));
    if (!userId)
      throw AppError.badRequest("This reset link is invalid or has expired.");

    const user = await userRepository.findById(userId);
    const newHash = await bcrypt.hash(password, 12);
    if (user?.tenant_id) {
      // Guest users have no tenant_id, same structural limit as every
      // other audit call site in this file, guarded rather than
      // silently attempted and failing the NOT NULL constraint.
      await withTransaction(async (client) => {
        await userRepository.updatePasswordHash(userId, newHash, client);
        await auditEventRepository.record(
          {
            tenantId: user.tenant_id!,
            actor: {
              type: "user",
              id: userId,
              email: user.email,
              name: [user.first_name, user.last_name].filter(Boolean).join(" "),
            },
            action: "auth.password_reset_confirmed",
            targetType: "user",
            targetId: userId,
            outcome: "allowed",
            requestId: requestContext.get()?.requestId,
          },
          client,
        );
      });
    } else {
      await userRepository.updatePasswordHash(userId, newHash);
    }
    await redisClient.del(passwordResetKey(token));

    await redisClient.set(blocklistKey(userId), "1", "EX", JWT_EXPIRY_SEC);

    await auditRepository.log({
      action: "updated",
      resource: "password_reset",
      resourceId: userId,
      userId,
    });

    logger.info("password_reset_confirmed", {
      event: "password_reset_confirmed",
      userId,
    });
    return {
      message: "Password reset. You can now sign in with your new password.",
    };
  }
  async login(
    input: LoginInput,
  ): Promise<
    | AuthTokens
    | { twoFactorRequired: true; challengeToken: string; method: "totp" }
    | { emailOtpRequired: true; method: "email" }
  > {
    const email = input.email.toLowerCase().trim();
    const user = await userRepository.findByEmail(email);

    if (!user) {
      await auditRepository.log({
        action: "login",
        resource: "user",
        newValue: { outcome: "failed", reason: "unknown_email", email },
      });
      throw AppError.unauthorized("Invalid email or password.");
    }

    const denyLogin = async (
      reason: string,
      error: AppError,
    ): Promise<never> => {
      if (user.tenant_id) {
        await withTransaction((client) =>
          auditEventRepository.record(
            {
              tenantId: user.tenant_id,
              actor: {
                type: "user",
                id: user.id,
                email: user.email,
                name: [user.first_name, user.last_name]
                  .filter(Boolean)
                  .join(" "),
              },
              action: "auth.login_failed",
              targetType: "user",
              targetId: user.id,
              outcome: "denied",
              denialReason: reason,
              requestId: requestContext.get()?.requestId,
            },
            client,
          ),
        );
      } else {
        await auditRepository.log({
          action: "login",
          resource: "user",
          resourceId: user.id,
          userId: user.id,
          newValue: { outcome: "denied", reason },
        });
      }
      throw error;
    };
    if (!(await bcrypt.compare(input.password, user.password_hash))) {
      await denyLogin(
        "incorrect_password",
        AppError.unauthorized("Invalid email or password."),
      );
      throw AppError.unauthorized("Invalid email or password.");
    }

    if (user.status === "suspended") {
      await denyLogin(
        "account_suspended",
        AppError.forbidden("Your account has been suspended. Contact support."),
      );
      throw AppError.forbidden(
        "Your account has been suspended. Contact support.",
      );
    }
    if (user.status === "inactive") {
      await denyLogin(
        "account_inactive",
        AppError.forbidden("Your account is inactive."),
      );
      throw AppError.forbidden("Your account is inactive.");
    }
    if (!user.is_email_verified) {
      await denyLogin(
        "email_not_verified",
        AppError.forbidden("Please verify your email before logging in."),
      );
      throw AppError.forbidden("Please verify your email before logging in.");
    }

    if (user.two_factor_enabled) {
      const challengeToken = nanoid(32);
      await redisClient.set(
        twoFactorChallengeKey(challengeToken),
        user.id,
        "EX",
        TWO_FACTOR_CHALLENGE_TTL_SEC,
      );
      await auditRepository.log({
        action: "login",
        resource: "user",
        resourceId: user.id,
        userId: user.id,
        newValue: { outcome: "2fa_challenge_issued" },
      });
      logger.info("two_factor_challenge_issued", {
        event: "two_factor_challenge_issued",
        userId: user.id,
      });
      return { twoFactorRequired: true, challengeToken, method: "totp" };
    }

    const otp = String(Math.floor(100000 + Math.random() * 900000));
    await redisClient.set(
      `login-otp:${user.email}`,
      JSON.stringify({ userId: user.id, otpHash: await bcrypt.hash(otp, 10) }),
      "EX",
      10 * 60, // 10 minutes
    );

    await publishNotifyAuthOtp({
      notificationId: uuid(),
      email: user.email,
      otp,
      firstName: user.first_name?.trim() || "there",
    });
    await auditRepository.log({
      action: "login",
      resource: "user",
      resourceId: user.id,
      userId: user.id,
      newValue: { outcome: "email_otp_issued" },
    });

    return {
      emailOtpRequired: true,
      method: "email",
    };
  }

  async verifyLoginEmailOtp(
    email: string,
    code: string,
    device?: SessionDeviceMeta,
  ): Promise<AuthTokens> {
    const normalizedEmail = email.toLowerCase().trim();
    const key = `login-otp:${normalizedEmail}`;
    const raw = await redisClient.get(key);

    if (!raw) {
      throw AppError.badRequest("Code expired. Please sign in again.");
    }

    let parsed: { userId: string; otpHash: string };
    try {
      parsed = JSON.parse(raw) as { userId: string; otpHash: string };
    } catch {
      await redisClient.del(key);
      throw AppError.badRequest("Code expired. Please sign in again.");
    }

    const { userId, otpHash } = parsed;

    if (!(await bcrypt.compare(code, otpHash))) {
      await auditRepository.log({
        action: "login",
        resource: "user",
        resourceId: userId,
        userId,
        newValue: { outcome: "failed", reason: "invalid_email_otp" },
      });
      throw AppError.badRequest("Invalid code.");
    }

    await redisClient.del(key);

    const user = await userRepository.findById(userId);
    if (!user) throw AppError.notFound("User.");

    if (user.status === "suspended") {
      await auditRepository.log({
        action: "login",
        resource: "user",
        resourceId: user.id,
        userId: user.id,
        newValue: { outcome: "blocked", reason: "suspended" },
      });
      throw AppError.forbidden(
        "Your account has been suspended. Contact support.",
      );
    }

    if (user.status === "inactive") {
      await auditRepository.log({
        action: "login",
        resource: "user",
        resourceId: user.id,
        userId: user.id,
        newValue: { outcome: "blocked", reason: "inactive" },
      });
      throw AppError.forbidden("Your account is inactive.");
    }

    if (!user.is_email_verified) {
      await auditRepository.log({
        action: "login",
        resource: "user",
        resourceId: user.id,
        userId: user.id,
        newValue: { outcome: "blocked", reason: "email_unverified" },
      });
      throw AppError.forbidden("Please verify your email before logging in.");
    }
    await withTransaction(async (client) => {
      await userRepository.updateById(
        user.id,
        { last_active_at: new Date() },
        client,
      );

      if (user.tenant_id) {
        await auditEventRepository.record(
          {
            tenantId: user.tenant_id,
            actor: {
              type: "user",
              id: user.id,
              email: user.email,
              name: [user.first_name, user.last_name].filter(Boolean).join(" "),
            },
            action: "auth.login_succeeded",
            targetType: "user",
            targetId: user.id,
            outcome: "allowed",
            requestId: requestContext.get()?.requestId,
          },
          client,
        );
      }
    });

    await auditRepository.log({
      action: "login",
      resource: "user",
      resourceId: user.id,
      userId: user.id,
      newValue: { outcome: "success", via: "email_otp" },
    });

    logger.info("user_logged_in_email_otp", {
      event: "user_logged_in_email_otp",
      userId: user.id,
      userType: user.user_type,
      requestId: requestContext.get()?.requestId,
    });

    const name = [user.first_name, user.last_name].filter(Boolean).join(" ");
    return this._buildTokens(
      user.id,
      user.user_type,
      name,
      user.tenant_id ?? undefined,
      device,
    );
  }

  async verifyTwoFactorLogin(
    challengeToken: string,
    code: string,
    device?: SessionDeviceMeta,
  ): Promise<AuthTokens> {
    const userId = await redisClient.get(twoFactorChallengeKey(challengeToken));
    if (!userId)
      throw AppError.badRequest(
        "This login challenge has expired. Please log in again.",
      );

    const user = await userRepository.findByIdWithSecrets(userId);
    if (!user) throw AppError.notFound("User.");

    let isValid = false;
    if (user.two_factor_secret) {
      isValid = authenticator.verify({
        token: code,
        secret: user.two_factor_secret,
      });
    }

    let consumedBackupCode = false;
    if (!isValid && user.two_factor_backup_codes?.length) {
      for (const hashed of user.two_factor_backup_codes) {
        if (await bcrypt.compare(code, hashed)) {
          isValid = true;
          consumedBackupCode = true;
          const remaining = user.two_factor_backup_codes.filter(
            (c) => c !== hashed,
          );
          await userRepository.updateById(user.id, {
            two_factor_backup_codes: remaining,
          });
          break;
        }
      }
    }

    if (!isValid) {
      await auditRepository.log({
        action: "login",
        resource: "user",
        resourceId: user.id,
        userId: user.id,
        newValue: { outcome: "failed", reason: "invalid_2fa_code" },
      });
      throw AppError.badRequest("Invalid or expired code.");
    }

    await redisClient.del(twoFactorChallengeKey(challengeToken));
    await withTransaction(async (client) => {
      await userRepository.updateById(
        user.id,
        { last_active_at: new Date() },
        client,
      );
      auditEventRepository.record(
        {
          tenantId: user.tenant_id,
          actor: {
            type: "user",
            id: user.id,
            email: user.email,
            name: [user.first_name, user.last_name].filter(Boolean).join(" "),
          },
          action: "auth.login_succeeded",
          targetType: "user",
          targetId: user.id,
          outcome: "allowed",
          metadata: { via: consumedBackupCode ? "backup_code" : "totp" },
          requestId: requestContext.get()?.requestId,
        },
        client,
      );
    });
    await auditRepository.log({
      action: "login",
      resource: "user",
      resourceId: user.id,
      userId: user.id,
      newValue: {
        outcome: "success",
        vi: consumedBackupCode ? "backup_code" : "totp",
      },
    });
    logger.info("user_logged_in_2fa", {
      event: "user_logged_in_2fa",
      userId: user.id,
      viaBackupCode: consumedBackupCode,
    });

    const name = [user.first_name, user.last_name].filter(Boolean).join(" ");
    return this._buildTokens(
      user.id,
      user.user_type,
      name,
      user.tenant_id ?? undefined,
      device,
    );
  }

  async disableTwoFactor(userId: string, password: string) {
    const user = await userRepository.findByIdWithSecrets(userId);
    if (!user) throw AppError.notFound("User.");
    if (!(await bcrypt.compare(password, user.password_hash))) {
      throw AppError.unauthorized("Incorrect password.");
    }

    await userRepository.updateById(userId, {
      two_factor_enabled: false,
      two_factor_secret: null,
      two_factor_backup_codes: null,
    });

    await auditRepository.log({
      action: "updated",
      resource: "two_factor_disabled",
      resourceId: userId,
      userId,
    });
    logger.info("two_factor_disabled", {
      event: "two_factor_disabled",
      userId,
    });

    return { message: "Two-factor authentication disabled." };
  }

  async verifyAndEnableTwoFactor(userId: string, token: string) {
    const user = await userRepository.findByIdWithSecrets(userId);
    if (!user) throw AppError.notFound("User.");
    if (!user.two_factor_secret)
      throw AppError.badRequest("Run setup before verifying.");
    if (user.two_factor_enabled)
      throw AppError.conflict("Two-factor authentication is already enabled.");

    const isValid = authenticator.verify({
      token,
      secret: user.two_factor_secret,
    });
    if (!isValid)
      throw AppError.badRequest(
        "Invalid code. Check your authenticator app and try again.",
      );

    const backupCodes = Array.from({ length: 8 }, () => nanoid(10));
    const hashedCodes = await Promise.all(
      backupCodes.map((c) => bcrypt.hash(c, 10)),
    );

    if (user.tenant_id) {
      await withTransaction(async (client) => {
        await userRepository.updateById(
          userId,
          { two_factor_enabled: true, two_factor_backup_codes: hashedCodes },
          client,
        );
        await auditEventRepository.record(
          {
            tenantId: user.tenant_id!,
            actor: {
              type: "user",
              id: userId,
              email: user.email,
              name: [user.first_name, user.last_name].filter(Boolean).join(" "),
            },
            action: "auth.mfa_enabled",
            targetType: "user",
            targetId: userId,
            outcome: "allowed",
            requestId: requestContext.get()?.requestId,
          },
          client,
        );
      });
    } else {
      await userRepository.updateById(userId, {
        two_factor_enabled: true,
        two_factor_backup_codes: hashedCodes,
      });
    }
    await auditRepository.log({
      action: "updated",
      resource: "two_factor_enabled",
      resourceId: userId,
      userId,
    });
    logger.info("two_factor_enabled", { event: "two_factor_enabled", userId });

    return { message: "Two-factor authentication enabled.", backupCodes };
  }
  async setupTwoFactor(userId: string) {
    const user = await userRepository.findByIdWithSecrets(userId);
    if (!user) throw AppError.notFound("User.");
    if (user.two_factor_enabled)
      throw AppError.conflict("Two-factor authentication is already enabled.");

    const secret = authenticator.generateSecret();
    await userRepository.updateById(userId, { two_factor_secret: secret });

    const otpauthUrl = authenticator.keyuri(
      user.email,
      "Bukking Platform",
      secret,
    );
    const qrCodeDataUrl = await QRCode.toDataURL(otpauthUrl);

    return { secret, qrCodeDataUrl };
  }
  async loginWithGoogle(
    code: string,
    codeVerifier: string,
    device?: SessionDeviceMeta,
  ): Promise<AuthTokens> {
    const { tokens } = await googleClient.getToken({ code, codeVerifier });
    if (!tokens.id_token)
      throw AppError.badRequest("Google did not return an identity token.");

    const ticket = await googleClient.verifyIdToken({
      idToken: tokens.id_token,
      audience: process.env.GOOGLE_CLIENT_ID,
    });
    const payload = ticket.getPayload();
    if (!payload?.email || !payload.sub)
      throw AppError.badRequest("Could not read your Google profile.");
    if (!payload.email_verified)
      throw AppError.forbidden("Your Google email is not verified.");

    let user = await userRepository.findByGoogleId(payload.sub);

    if (!user) {
      const existingByEmail = await userRepository.findByEmail(payload.email);

      if (existingByEmail) {
        // Auto-link: Google has already verified this email, safe to
        // attach the Google identity to the existing password account.
        await userRepository.updateById(existingByEmail.id, {
          google_id: payload.sub,
          is_email_verified: true,
        });
        user = { ...existingByEmail, google_id: payload.sub };
      } else {
        // Brand new signup via Google, defaults to guest, matching the
        // same default a plain email signup would get without an
        // explicit host onboarding flow. password_hash is a random,
        // never-revealed value, this account can only ever log in via
        // Google unless a separate "set a password" flow is added later.
        const randomPassword = await bcrypt.hash(nanoid(32), 12);
        const created = await userRepository.create({
          email: payload.email,
          passwordHash: randomPassword,
          userType: "guest",
          firstName: payload.given_name,
          lastName: payload.family_name,
        });
        await userRepository.updateById(created.id, {
          google_id: payload.sub,
          is_email_verified: true,
        });
        user = await userRepository.findByIdWithSecrets(created.id);
        if (!user)
          throw AppError.internal("User creation failed unexpectedly.");
      }
    }

    if (user.status === "suspended")
      throw AppError.forbidden(
        "Your account has been suspended. Contact support.",
      );
    if (user.status === "inactive")
      throw AppError.forbidden("Your account is inactive.");

    await userRepository.updateById(user.id, { last_active_at: new Date() });
    await auditRepository.log({
      action: "login",
      resource: "user",
      resourceId: user.id,
      userId: user.id,
      newValue: { via: "google_oauth" },
    });
    logger.info("user_logged_in_google", {
      event: "user_logged_in_google",
      userId: user.id,
    });

    const name = [user.first_name, user.last_name].filter(Boolean).join(" ");
    return this._buildTokens(
      user.id,
      user.user_type,
      name,
      user.tenant_id ?? undefined,
      device,
    );
  }
}

export const authService = instrumentService(new AuthService(), measureAuthOp, {
  initiateOnboarding: "initiate_onboarding",
  confirmEmail: "confirm_email",
  registerGuest: "register_guest",
  registerHost: "register_host",
  refreshToken: "refresh_token",
  logout: "logout",
  resendOtp: "resend_otp",
  changePassword: "change_password",
  requestPasswordReset: "request_password_reset",
  confirmPasswordReset: "confirm_password_reset",
  login: "login",
  verifyLoginEmailOtp: "verify_email_otp",
  verifyTwoFactorLogin: "verify_totp",
  loginWithGoogle: "login_google",
  disableTwoFactor: "disable_2fa",
}); 
