import { Tenant, tenantRepository } from "./tenant.repository";
import {
  query,
  AppError,
  withTransaction,
  requestContext,
  redisClient,
  logger,
} from "@booking/shared";
import { reviewRepository } from "../review/review.repository";
import { CancellationPolicyTier } from "../../types";
import { escrowRepository } from "../escrow/escrow.repository";
import { propertyRepository } from "../property/property.repository";
import { bookingRepository } from "../booking/booking.repository";
import { auditRepository } from "../audit/audit.repository";
import { auditEventRepository } from "../audit/auditEvent.repository";
import { caddyService } from "../../infra/providers/caddy.service";
import { nanoid } from "nanoid";
import {
  verifyDomainCNAME,
  verifyDomainTXT,
} from "../../utils/domainVerification";
import { PoolClient } from "pg";
export const tenantService = {
  async getMyTenant(tenantId: string) {
    const tenant = await tenantRepository.findById(tenantId);
    if (!tenant) throw AppError.notFound("Tenant not found.");
    return tenant;
  },

  async updateSettings(
    tenantId: string,
    actorUserId: string,
    body: { timezone?: string; currency?: string; locale?: string },
  ) {
    const updated = await tenantRepository.updateSettings(tenantId, body);
    const client = requestContext.get()?.dbClient;
    const payload = {
      tenantId,
      actor: { type: "user" as const, id: actorUserId },
      action: "tenant.settings_updated",
      targetType: "tenant",
      targetId: tenantId,
      after: body,
      outcome: "allowed" as const,
      requestId: requestContext.get()?.requestId,
    };
    if (client) await auditEventRepository.record(payload, client);
    else await withTransaction((c) => auditEventRepository.record(payload, c));
    return updated;
  },

  async updateProfile(
    tenantId: string,
    actorUserId: string,
    body: {
      bio?: string;
      avatarUrl?: string;
      city?: string;
      state?: string;
      country?: string;
    },
  ) {
    const updated = await tenantRepository.updateProfile(tenantId, body);
    const client = requestContext.get()?.dbClient;
    const payload = {
      tenantId,
      actor: { type: "user" as const, id: actorUserId },
      action: "tenant.profile_updated",
      targetType: "tenant",
      targetId: tenantId,
      after: body,
      outcome: "allowed" as const,
      requestId: requestContext.get()?.requestId,
    };
    if (client) await auditEventRepository.record(payload, client);
    else await withTransaction((c) => auditEventRepository.record(payload, c));
    return updated;
  },

  async updateCancellationPolicy(
    tenantId: string,
    actorUserId: string,
    policy: CancellationPolicyTier[],
  ) {
    const updated = await tenantRepository.updateCancellationPolicy(
      tenantId,
      policy,
    );
    const client = requestContext.get()?.dbClient;
    const payload = {
      tenantId,
      actor: { type: "user" as const, id: actorUserId },
      action: "tenant.cancellation_policy_updated",
      targetType: "tenant",
      targetId: tenantId,
      after: { policy },
      outcome: "allowed" as const,
      requestId: requestContext.get()?.requestId,
    };
    if (client) await auditEventRepository.record(payload, client);
    else await withTransaction((c) => auditEventRepository.record(payload, c));
    return updated;
  },

  async listAll(page: number, limit: number) {
    return tenantRepository.listAll(page, limit);
  },

  async suspend(tenantId: string, actorUserId: string) {
    return withTransaction(async (client) => {
      const updated = await tenantRepository.updateStatus(
        tenantId,
        "suspended",
        client,
      );
      if (!updated) throw AppError.notFound("Tenant not found.");
      await auditEventRepository.record(
        {
          tenantId,
          actor: { type: "user", id: actorUserId },
          action: "tenant.suspended",
          targetType: "tenant",
          targetId: tenantId,
          outcome: "allowed",
          requestId: requestContext.get()?.requestId,
        },
        client,
      );
      return updated;
    });
  },

  async activate(tenantId: string, actorUserId: string) {
    return withTransaction(async (client) => {
      const updated = await tenantRepository.updateStatus(
        tenantId,
        "active",
        client,
      );
      if (!updated) throw AppError.notFound("Tenant not found.");
      await auditEventRepository.record(
        {
          tenantId,
          actor: { type: "user", id: actorUserId },
          action: "tenant.activated",
          targetType: "tenant",
          targetId: tenantId,
          outcome: "allowed",
          requestId: requestContext.get()?.requestId,
        },
        client,
      );
      return updated;
    });
  },

  /**
   * Public seller/host profile. No auth. Must never leak dashboard-only
   * fields (occupancy status, current tenant/guest names on room types),
   * same public-vs-dashboard boundary already enforced for properties.
   */
  // async getPublicProfile(tenantId: string) {
  //   const tenant = await tenantRepository.findById(tenantId);
  //   if (!tenant || tenant.status !== "active") throw AppError.notFound("Host not found.");

  //   const properties = await query<{ id: string; name: string; images: string[]; city: string; property_type: string }>(
  //     `SELECT id, name, images, address->>'city' AS city, property_type
  //      FROM properties WHERE tenant_id = $1 AND status = 'active'
  //      ORDER BY created_at DESC`,
  //     [tenantId],
  //   );

  //   const propertyIds = properties.map((p) => p.id);
  //   // Curated columns, same discipline as the properties query above,
  //   // not SELECT *: this is a public, unauthenticated endpoint, "probably
  //   // nothing sensitive on room_types" isn't a guarantee, explicit is.
  //   const roomTypes = await query<{ id: string; property_id: string; name: string; base_price_ngn: number; max_occupancy: number; images: string[] }>(
  //     `SELECT id, property_id, name, base_price_ngn, max_occupancy, images
  //      FROM room_types WHERE property_id = ANY($1::uuid[]) AND status = 'active'
  //      ORDER BY base_price_ngn ASC`,
  //     [propertyIds],
  //   );

  //   const propertiesWithRoomTypes = properties.map((p) => ({
  //     ...p,
  //     roomTypes: roomTypes.filter((r) => r.property_id === p.id),
  //   }));

  //   const [recentReviews, statsRow] = await Promise.all([
  //     reviewRepository.findByTenant(tenantId, 1, 5),
  //     query<{ avg_rating: string | null; total_reviews: string; total_bookings: string }>(
  //       `SELECT
  //          (SELECT AVG(rating) FROM reviews WHERE tenant_id = $1 AND status = 'approved') AS avg_rating,
  //          (SELECT COUNT(*) FROM reviews WHERE tenant_id = $1 AND status = 'approved') AS total_reviews,
  //          (SELECT COUNT(*) FROM bookings WHERE tenant_id = $1 AND status IN ('confirmed','checked_in','checked_out')) AS total_bookings`,
  //       [tenantId],
  //     ),
  //   ]);

  //   const stats = statsRow[0];

  //   return {
  //     tenant: {
  //       id: tenant.id, name: tenant.name, slug: tenant.slug,
  //       createdAt: tenant.created_at, settings: tenant.settings,
  //       bio: tenant.bio ?? null,
  //       avatarUrl: tenant.avatar_url ?? null,
  //       city: tenant.city ?? null,
  //       state: tenant.state ?? null,
  //       country: tenant.country ?? null,
  //     },
  //     properties: propertiesWithRoomTypes,
  //     recentReviews,
  //     stats: {
  //       avgRating:     stats?.avg_rating ? Number(Number(stats.avg_rating).toFixed(2)) : 0,
  //       totalReviews:  Number(stats?.total_reviews ?? 0),
  //       totalBookings: Number(stats?.total_bookings ?? 0),
  //     },
  //   };
  // },
  /**
   * Public seller/host profile. No auth. Must never leak dashboard-only
   * fields (occupancy status, current tenant/guest names on room types),
   * same public-vs-dashboard boundary already enforced for properties.
   */
  async getPublicProfile(tenantId: string) {
    const tenant = await tenantRepository.findById(tenantId);
    if (!tenant || tenant.status !== "active")
      throw AppError.notFound("Host not found.");

    // One round trip via LEFT JOIN (properties with zero active room types
    // still appear, room-type columns come back NULL for that row) rather
    // than two separate queries. Same pattern already used in
    // searchPublicProperties elsewhere in this file. Curated columns on
    // both sides, not SELECT *, this is a public unauthenticated
    // endpoint, "probably nothing sensitive" isn't a guarantee.
    // Denormalized: a property with 3 room types comes back as 3 rows,
    // its own columns repeated on each, grouped back into the nested
    // shape below.
    const rows = await query<{
      property_id: string;
      property_name: string;
      property_images: string[];
      city: string;
      property_type: string;
      room_type_id: string | null;
      room_type_name: string | null;
      base_price_ngn: number | null;
      max_occupancy: number | null;
      room_type_images: string[] | null;
    }>(
      `SELECT
         p.id AS property_id, p.name AS property_name, p.images AS property_images,
         p.address->>'city' AS city, p.property_type,
         rt.id AS room_type_id, rt.name AS room_type_name, rt.base_price_ngn, rt.max_occupancy, rt.images AS room_type_images
       FROM properties p
       LEFT JOIN room_types rt ON rt.property_id = p.id AND rt.status = 'active'
       WHERE p.tenant_id = $1 AND p.status = 'active'
       ORDER BY p.created_at DESC, rt.base_price_ngn ASC`,
      [tenantId],
    );

    const byProperty = new Map<
      string,
      {
        id: string;
        name: string;
        images: string[];
        city: string;
        property_type: string;
        roomTypes: {
          id: string;
          name: string;
          base_price_ngn: number;
          max_occupancy: number;
          images: string[];
        }[];
      }
    >();

    for (const row of rows) {
      if (!byProperty.has(row.property_id)) {
        byProperty.set(row.property_id, {
          id: row.property_id,
          name: row.property_name,
          images: row.property_images,
          city: row.city,
          property_type: row.property_type,
          roomTypes: [],
        });
      }
      if (row.room_type_id) {
        byProperty.get(row.property_id)!.roomTypes.push({
          id: row.room_type_id,
          name: row.room_type_name!,
          base_price_ngn: row.base_price_ngn!,
          max_occupancy: row.max_occupancy!,
          images: row.room_type_images ?? [],
        });
      }
    }

    const propertiesWithRoomTypes = Array.from(byProperty.values());

    const [recentReviews, statsRow] = await Promise.all([
      reviewRepository.findByTenant(tenantId, 1, 5),
      query<{
        avg_rating: string | null;
        total_reviews: string;
        total_bookings: string;
      }>(
        `SELECT
           (SELECT AVG(rating) FROM reviews WHERE tenant_id = $1 AND status = 'approved') AS avg_rating,
           (SELECT COUNT(*) FROM reviews WHERE tenant_id = $1 AND status = 'approved') AS total_reviews,
           (SELECT COUNT(*) FROM bookings WHERE tenant_id = $1 AND status IN ('confirmed','checked_in','checked_out')) AS total_bookings`,
        [tenantId],
      ),
    ]);

    const stats = statsRow[0];

    return {
      tenant: {
        id: tenant.id,
        name: tenant.name,
        slug: tenant.slug,
        createdAt: tenant.created_at,
        settings: tenant.settings,
        bio: tenant.bio ?? null,
        avatarUrl: tenant.avatar_url ?? null,
        city: tenant.city ?? null,
        state: tenant.state ?? null,
        country: tenant.country ?? null,
      },
      properties: propertiesWithRoomTypes,
      recentReviews,
      stats: {
        avgRating: stats?.avg_rating
          ? Number(Number(stats.avg_rating).toFixed(2))
          : 0,
        totalReviews: Number(stats?.total_reviews ?? 0),
        totalBookings: Number(stats?.total_bookings ?? 0),
      },
    };
  },

  async getAdminDetail(tenantId: string) {
    const tenant = await tenantRepository.findById(tenantId);
    if (!tenant) throw AppError.notFound("Tenant not found.");

    const [
      escrowStats,
      propertyStats,
      bookingStats,
      recentPurchases,
      recentActivity,
    ] = await Promise.all([
      escrowRepository.getStatsForTenant(tenantId),
      propertyRepository.getStatsForTenant(tenantId),
      bookingRepository.getStatsForTenant(tenantId),
      escrowRepository.listByTenant(tenantId, 1, 10),
      auditRepository.listByTenant(tenantId, 1, 20),
    ]);

    return {
      tenant,
      stats: {
        escrow: escrowStats,
        properties: propertyStats,
        bookings: bookingStats,
      },
      recentPurchases,
      recentActivity,
    };
  },

  async claimSubdomain(
    tenantId: string,
    requested: string,
    actorUserId: string,
  ) {
    const base = requested
      .toLowerCase()
      .trim()
      .replace(/[^a-z0-9\s-]/g, "")
      .replace(/\s+/g, "-")
      .replace(/-+/g, "-")
      .replace(/^-|-$/g, "")
      .slice(0, 40);

    if (!base) {
      throw AppError.badRequest(
        "That name produces an empty subdomain, use letters or numbers.",
      );
    }

    let candidate = base;
    let existing = await tenantRepository.findBySubdomain(candidate);
    for (
      let attempt = 1;
      existing && existing.id !== tenantId && attempt <= 10;
      attempt++
    ) {
      candidate = `${base.slice(0, 36)}-${attempt}`;
      existing = await tenantRepository.findBySubdomain(candidate);
    }
    if (existing && existing.id !== tenantId) {
      throw AppError.conflict(
        "Could not find an available subdomain close to that name, try something more specific.",
      );
    }

    return withTransaction(async (client) => {
      const updated = await tenantRepository.setSubdomain(
        tenantId,
        candidate,
        client,
      );
      if (!updated) throw AppError.notFound("Tenant not found.");

      if (process.env.CADDY_ADMIN_URL) {
        const routeId = `tenant-subdomain-${tenantId}`;
        try {
          await caddyService.registerRoute(routeId, candidate, true);
          await tenantRepository.setCaddySubdomainRouteId(
            tenantId,
            routeId,
            client,
          );
        } catch (err) {
          logger.error("caddy_subdomain_registration_failed", {
            event: "caddy_subdomain_registration_failed",
            tenantId,
            subdomain: candidate,
            error: (err as Error).message,
          });
        }
      }

      await auditEventRepository.record(
        {
          tenantId,
          actor: { type: "user", id: actorUserId },
          action: "tenant.subdomain_claimed",
          targetType: "tenant",
          targetId: tenantId,
          after: { subdomain: candidate },
          outcome: "allowed",
          requestId: requestContext.get()?.requestId,
        },
        client,
      );

      return updated;

      await auditEventRepository.record(
        {
          tenantId,
          actor: { type: "user", id: actorUserId },
          action: "tenant.subdomain_claimed",
          targetType: "tenant",
          targetId: tenantId,
          after: { subdomain: candidate },
          outcome: "allowed",
          requestId: requestContext.get()?.requestId,
        },
        client,
      );

      return updated;
    });
  },

  async resolveBySubdomain(subdomain: string): Promise<Tenant | null> {
    const cacheKey = `tenant:subdomain:${subdomain}`;
    const cached = await redisClient.get(cacheKey);
    if (cached) return JSON.parse(cached) as Tenant;

    const tenant = await tenantRepository.findBySubdomain(subdomain);
    if (tenant)
      await redisClient.set(cacheKey, JSON.stringify(tenant), "EX", 3600);
    return tenant;
  },

  async addCustomDomain(tenantId: string, domain: string, actorUserId: string) {
    const normalized = domain.toLowerCase().trim();
    const existing = await tenantRepository.findByCustomDomain(normalized);
    if (existing && existing.id !== tenantId) {
      throw AppError.conflict(
        `The domain "${normalized}" is already registered to another tenant.`,
      );
    }

    const verificationToken = `bukkings-verify-${nanoid(24)}`;
    const updated = await tenantRepository.setPendingCustomDomain(
      tenantId,
      normalized,
      verificationToken,
    );
    if (!updated) throw AppError.notFound("Tenant not found.");

    await auditRepository.log({
      action: "updated",
      resource: "tenant_custom_domain",
      resourceId: tenantId,
      tenantId,
      userId: actorUserId,
      newValue: { domain: normalized, status: "pending" },
    });

    return updated;
  },

  async verifyCustomDomain(tenantId: string, actorUserId: string) {
    const tenant = await tenantRepository.findById(tenantId);
    if (!tenant?.custom_domain)
      throw AppError.notFound("No custom domain set for this tenant.");

    if (tenant.custom_domain_status === "verified") return tenant;

    if (!process.env.CADDY_ADMIN_URL) {
      throw AppError.badRequest(
        "Custom domain verification isn't available yet, this platform is still running on infrastructure that doesn't support it. Check back after the Hetzner migration.",
      );
    }

    const [cnameOk, txtOk] = await Promise.all([
      verifyDomainCNAME(tenant.custom_domain),
      tenant.custom_domain_verification_token
        ? verifyDomainTXT(
            tenant.custom_domain,
            tenant.custom_domain_verification_token,
          )
        : Promise.resolve(false),
    ]);

    if (!cnameOk || !txtOk) {
      await tenantRepository.markCustomDomainFailed(tenantId);
      throw AppError.badRequest(
        `DNS records not fully propagated (CNAME: ${cnameOk ? "ok" : "missing"}, TXT: ${txtOk ? "ok" : "missing"}). Retry in a few minutes.`,
      );
    }

    const routeId = `tenant-custom-${tenantId}`;

    return withTransaction(async (client) => {
      await caddyService.registerRoute(routeId, tenant.custom_domain!, false);
      const updated = await tenantRepository.markCustomDomainVerified(
        tenantId,
        routeId,
        client,
      );
      if (!updated) throw AppError.notFound("Tenant not found.");

      await auditEventRepository.record(
        {
          tenantId,
          actor: { type: "user", id: actorUserId },
          action: "tenant.custom_domain_verified",
          targetType: "tenant",
          targetId: tenantId,
          after: { domain: tenant.custom_domain },
          outcome: "allowed",
          requestId: requestContext.get()?.requestId,
        },
        client,
      );

      return updated;
    });
  },

  async removeCustomDomain(tenantId: string, actorUserId: string) {
    const tenant = await tenantRepository.findById(tenantId);
    if (!tenant?.custom_domain)
      throw AppError.notFound("No custom domain set for this tenant.");

    if (tenant.caddy_custom_route_id && process.env.CADDY_ADMIN_URL) {
      await caddyService.deregisterRoute(tenant.caddy_custom_route_id);
    }

    return withTransaction(async (client) => {
      const updated = await tenantRepository.clearCustomDomain(
        tenantId,
        client,
      );

      await auditEventRepository.record(
        {
          tenantId,
          actor: { type: "user", id: actorUserId },
          action: "tenant.custom_domain_removed",
          targetType: "tenant",
          targetId: tenantId,
          before: { domain: tenant.custom_domain },
          outcome: "allowed",
          requestId: requestContext.get()?.requestId,
        },
        client,
      );

      return updated;
    });
  },

  async resolveAndClaimSubdomain(
    tenantId: string,
    requested: string,
    client: PoolClient,
  ): Promise<string | null> {
    const base = requested
      .toLowerCase()
      .trim()
      .replace(/[^a-z0-9\s-]/g, "")
      .replace(/\s+/g, "-")
      .replace(/-+/g, "-")
      .replace(/^-|-$/g, "")
      .slice(0, 40);

    if (!base) {
      throw AppError.badRequest(
        "That name produces an empty subdomain, use letters or numbers.",
      );
    }

    let candidate = base;
    let existing = await tenantRepository.findBySubdomain(candidate);
    for (
      let attempt = 1;
      existing && existing.id !== tenantId && attempt <= 10;
      attempt++
    ) {
      candidate = `${base.slice(0, 36)}-${attempt}`;
      existing = await tenantRepository.findBySubdomain(candidate);
    }
    if (existing && existing.id !== tenantId) {
      return null;
    }

    const updated = await tenantRepository.setSubdomain(
      tenantId,
      candidate,
      client,
    );
    if (!updated) throw AppError.notFound("Tenant not found.");

    if (process.env.CADDY_ADMIN_URL) {
      const routeId = `tenant-subdomain-${tenantId}`;
      try {
        await caddyService.registerRoute(routeId, candidate, true);
        await tenantRepository.setCaddySubdomainRouteId(
          tenantId,
          routeId,
          client,
        );
      } catch (err) {
        logger.error("caddy_subdomain_registration_failed", {
          event: "caddy_subdomain_registration_failed",
          tenantId,
          subdomain: candidate,
          error: (err as Error).message,
        });
      }
    }

    return candidate;
  },
};
