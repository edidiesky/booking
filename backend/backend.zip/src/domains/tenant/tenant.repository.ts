import { PoolClient } from "pg";
import { query, queryOne } from "@booking/shared";
import {
  TenantStatus,
  CancellationPolicyTier,
  TenantSettings,
} from "../../types";

export interface Tenant {
  id: string;
  slug: string;
  name: string;
  owner_user_id: string;
  platform_fee_pct: number;
  cancellation_policy: CancellationPolicyTier[];
  status: TenantStatus;
  settings: TenantSettings;
  bio?: string;
  avatar_url?: string;
  city?: string;
  state?: string;
  country?: string;
  created_at: Date;
  updated_at: Date;
  subdomain: string | null;
  custom_domain: string | null;
  custom_domain_status: "none" | "pending" | "verified" | "failed";
  custom_domain_verified_at: string | null;
  custom_domain_verification_token: string | null;
  caddy_subdomain_route_id: string | null;
  caddy_custom_route_id: string | null;
}

export const tenantRepository = {
  async findBySlug(slug: string): Promise<Tenant | null> {
    return queryOne<Tenant>(`SELECT * FROM tenants WHERE slug = $1 LIMIT 1`, [
      slug,
    ]);
  },

  async findById(id: string): Promise<Tenant | null> {
    return queryOne<Tenant>(`SELECT * FROM tenants WHERE id = $1`, [id]);
  },

  async create(
    data: {
      slug: string;
      name: string;
      ownerUserId: string;
      platformFeePct?: number;
    },
    client?: PoolClient,
  ): Promise<Tenant> {
    const sql = `INSERT INTO tenants (slug, name, owner_user_id, platform_fee_pct, status)
               VALUES ($1, $2, $3, $4, 'active') RETURNING *`;
    const params = [
      data.slug,
      data.name,
      data.ownerUserId,
      data.platformFeePct ?? 10.0,
    ];
    const row = client
      ? ((await client.query(sql, params)).rows[0] as Tenant)
      : await queryOne<Tenant>(sql, params);
    return row!;
  },
  async updateSettings(
    id: string,
    settings: Partial<TenantSettings>,
  ): Promise<Tenant | null> {
    return queryOne<Tenant>(
      `UPDATE tenants SET settings = settings || $1::jsonb, updated_at = now() WHERE id = $2 RETURNING *`,
      [JSON.stringify(settings), id],
    );
  },

  async updateProfile(
    id: string,
    data: {
      bio?: string;
      avatarUrl?: string;
      city?: string;
      state?: string;
      country?: string;
    },
  ): Promise<Tenant | null> {
    return queryOne<Tenant>(
      `UPDATE tenants SET
         bio        = COALESCE($1, bio),
         avatar_url = COALESCE($2, avatar_url),
         city       = COALESCE($3, city),
         state      = COALESCE($4, state),
         country    = COALESCE($5, country),
         updated_at = now()
       WHERE id = $6
       RETURNING *`,
      [
        data.bio ?? null,
        data.avatarUrl ?? null,
        data.city ?? null,
        data.state ?? null,
        data.country ?? null,
        id,
      ],
    );
  },

  async updateCancellationPolicy(
    id: string,
    policy: CancellationPolicyTier[],
  ): Promise<Tenant | null> {
    return queryOne<Tenant>(
      `UPDATE tenants SET cancellation_policy = $1::jsonb, updated_at = now() WHERE id = $2 RETURNING *`,
      [JSON.stringify(policy), id],
    );
  },

  async slugExists(slug: string): Promise<boolean> {
    const row = await queryOne<{ count: string }>(
      `SELECT COUNT(*) AS count FROM tenants WHERE slug = $1`,
      [slug],
    );
    return parseInt(row?.count ?? "0", 10) > 0;
  },

  async listAll(page = 1, limit = 20): Promise<Tenant[]> {
    const offset = (page - 1) * limit;
    return query<Tenant>(
      `SELECT * FROM tenants ORDER BY created_at DESC LIMIT $1 OFFSET $2`,
      [limit, offset],
    );
  },
  async updateStatus(
    id: string,
    status: TenantStatus,
    client?: PoolClient,
  ): Promise<Tenant | null> {
    const sql = `UPDATE tenants SET status = $1, updated_at = now() WHERE id = $2 RETURNING *`;
    if (client)
      return (await client.query<Tenant>(sql, [status, id])).rows[0] ?? null;
    return queryOne<Tenant>(sql, [status, id]);
  },
  async countAllByStatus(): Promise<{
    active: number;
    suspended: number;
    draft: number;
  }> {
    const row = await queryOne<{
      active: string;
      suspended: string;
      draft: string;
    }>(
      `SELECT
       COUNT(*) FILTER (WHERE status = 'active')    AS active,
       COUNT(*) FILTER (WHERE status = 'suspended')  AS suspended,
       COUNT(*) FILTER (WHERE status = 'draft')      AS draft
     FROM tenants`,
    );
    return {
      active: Number(row?.active ?? 0),
      suspended: Number(row?.suspended ?? 0),
      draft: Number(row?.draft ?? 0),
    };
  },

  async findByCustomDomain(domain: string): Promise<Tenant | null> {
    return queryOne<Tenant>(
      `SELECT * FROM tenants WHERE custom_domain = $1 LIMIT 1`,
      [domain],
    );
  },

  async setCaddySubdomainRouteId(
    tenantId: string,
    routeId: string,
    client?: PoolClient,
  ): Promise<void> {
    const sql = `UPDATE tenants SET caddy_subdomain_route_id = $1 WHERE id = $2`;
    if (client) {
      await client.query(sql, [routeId, tenantId]);
      return;
    }
    await query(sql, [routeId, tenantId]);
  },

  async setPendingCustomDomain(
    tenantId: string,
    domain: string,
    verificationToken: string,
  ): Promise<Tenant | null> {
    return queryOne<Tenant>(
      `UPDATE tenants
       SET custom_domain = $1, custom_domain_status = 'pending',
           custom_domain_verification_token = $2, updated_at = now()
       WHERE id = $3 RETURNING *`,
      [domain, verificationToken, tenantId],
    );
  },

  async markCustomDomainVerified(
    tenantId: string,
    caddyRouteId: string,
    client?: PoolClient,
  ): Promise<Tenant | null> {
    const sql = `UPDATE tenants
       SET custom_domain_status = 'verified', custom_domain_verified_at = now(),
           caddy_custom_route_id = $1, updated_at = now()
       WHERE id = $2 RETURNING *`;
    if (client)
      return (
        (await client.query<Tenant>(sql, [caddyRouteId, tenantId])).rows[0] ??
        null
      );
    return queryOne<Tenant>(sql, [caddyRouteId, tenantId]);
  },

  async markCustomDomainFailed(tenantId: string): Promise<void> {
    await query(
      `UPDATE tenants SET custom_domain_status = 'failed', updated_at = now() WHERE id = $1`,
      [tenantId],
    );
  },

  async clearCustomDomain(
    tenantId: string,
    client?: PoolClient,
  ): Promise<Tenant | null> {
    const sql = `UPDATE tenants
       SET custom_domain = NULL, custom_domain_status = 'none',
           custom_domain_verified_at = NULL, custom_domain_verification_token = NULL,
           caddy_custom_route_id = NULL, updated_at = now()
       WHERE id = $1 RETURNING *`;
    if (client)
      return (await client.query<Tenant>(sql, [tenantId])).rows[0] ?? null;
    return queryOne<Tenant>(sql, [tenantId]);
  },

  async findBySubdomain(subdomain: string): Promise<Tenant | null> {
    return queryOne<Tenant>(
      `SELECT * FROM tenants WHERE subdomain = $1 LIMIT 1`,
      [subdomain],
    );
  },

  async setSubdomain(
    tenantId: string,
    subdomain: string,
    client?: PoolClient,
  ): Promise<Tenant | null> {
    const sql = `UPDATE tenants SET subdomain = $1, updated_at = now() WHERE id = $2 RETURNING *`;
    if (client)
      return (
        (await client.query<Tenant>(sql, [subdomain, tenantId])).rows[0] ?? null
      );
    return queryOne<Tenant>(sql, [subdomain, tenantId]);
  },
};
