import { userRepository } from "../auth/auth.repository";
import { auditRepository } from "../audit/audit.repository";
import { AppError } from "@booking/shared";
import { paymentRepository } from "../payment/payment.repository";
import { BookingStatus } from "../../types";
import { propertyRepository } from "../property/property.repository";
import { bookingRepository } from "../booking/booking.repository";
import { tenantRepository } from "../tenant/tenant.repository";
import { sellerNotificationRepository } from "../seller-notification/seller.notification.repository";
import { escrowRepository } from "../escrow/escrow.repository";

export class AdminService {
  async listGuests(page: number, limit: number) {
    const [rows, totalCount] = await Promise.all([
      userRepository.listByType("guest", page, limit),
      userRepository.countByType("guest"),
    ]);
    const guests = rows.map((g) => ({
      id: g.id,
      firstName: g.first_name,
      lastName: g.last_name,
      email: g.email,
      phone: g.phone,
      profileImage: g.profile_image,
      status: g.status,
      isEmailVerified: g.is_email_verified,
      isPhoneVerified: g.is_phone_verified,
      twoFactorEnabled: g.two_factor_enabled,
      googleId: g.google_id,
      lastActiveAt: g.last_active_at,
      createdAt: g.created_at,
    }));
    return {
      guests,
      page,
      limit,
      totalCount,
      totalPages: Math.max(1, Math.ceil(totalCount / limit)),
    };
  }

  async listAdministrators(page: number, limit: number) {
    const [administrators, totalCount] = await Promise.all([
      userRepository.listByType("platform:admin", page, limit),
      userRepository.countByType("platform:admin"),
    ]);
    return {
      administrators,
      page,
      limit,
      totalCount,
      totalPages: Math.max(1, Math.ceil(totalCount / limit)),
    };
  }

  async promoteToAdministrator(userId: string) {
    const user = await userRepository.findById(userId);
    if (!user) throw AppError.notFound("User not found.");
    if (user.user_type === "platform:admin")
      throw AppError.conflict("Already a platform administrator.");
    return userRepository.updateUserType(userId, "platform:admin");
  }

  async demoteAdministrator(userId: string) {
    const user = await userRepository.findById(userId);
    if (!user) throw AppError.notFound("User not found.");
    if (user.user_type !== "platform:admin")
      throw AppError.conflict("Not currently a platform administrator.");
    return userRepository.updateUserType(userId, "guest");
  }

  async listAuditLogs(page: number, limit: number) {
    const [rows, totalCount] = await Promise.all([
      auditRepository.listAll(page, limit),
      auditRepository.countAll(),
    ]);
    const logs = rows.map((l) => ({
      id: l.id,
      action: l.action,
      resource: l.resource,
      resourceId: l.resource_id,
      oldValue: l.old_value,
      newValue: l.new_value,
      ipAddress: l.ip_address,
      actorFirstName: l.actor_first_name,
      actorLastName: l.actor_last_name,
      tenantName: l.tenant_name,
      createdAt: l.created_at,
    }));
    return {
      logs,
      page,
      limit,
      totalCount,
      totalPages: Math.max(1, Math.ceil(totalCount / limit)),
    };
  }
  async listProperties(page: number, limit: number) {
    const [rows, totalCount] = await Promise.all([
      propertyRepository.listAllForAdmin(page, limit),
      propertyRepository.countAllForAdmin(),
    ]);
    const properties = rows.map((p) => ({
      id: p.id,
      name: p.name,
      description: p.description,
      propertyType: p.property_type,
      address: p.address,
      status: p.status,
      checkInTime: p.check_in_time,
      checkOutTime: p.check_out_time,
      tenantId: p.tenant_id,
      tenantName: p.tenant_name,
      tenantEmail: p.tenant_email,
      createdAt: p.created_at,
      updatedAt: p.updated_at,
    }));
    return {
      properties,
      page,
      limit,
      totalCount,
      totalPages: Math.max(1, Math.ceil(totalCount / limit)),
    };
  }

  async listBookings(page: number, limit: number, status?: BookingStatus) {
    const rows = await bookingRepository.listAllForAdmin({
      status,
      page,
      limit,
    });
    const bookings = rows.map((b) => ({
      id: b.id,
      bookingRef: b.booking_ref,
      status: b.status,
      checkIn: b.check_in,
      checkOut: b.check_out,
      nights: b.nights,
      guestCount: b.guest_count,
      roomsCount: b.rooms_count,
      totalAmountNgn: b.total_amount_ngn,
      platformFeeNgn: b.platform_fee_ngn,
      hostPayoutNgn: b.host_payout_ngn,
      createdAt: b.created_at,
      tenantName: b.tenant_name,
      guestFirstName: b.guest_first_name,
      guestLastName: b.guest_last_name,
      guestUserId: b.guest_user_id,
      propertyName: b.property_name,
      roomTypeName: b.room_type_name,
      tenantId: b.tenant_id,
      tenantEmail: b.tenant_email,
      guestEmail: b.guest_email,
      roomTypeImages: b.room_type_images,
    }));
    return { bookings, page, limit };
  }

  async listPayments(page: number, limit: number) {
    const rows = await paymentRepository.listAllForAdmin(page, limit);
    const payments = rows.map((p) => ({
      id: p.id,
      bookingId: p.booking_id,
      gateway: p.gateway,
      transactionId: p.transaction_id,
      amountNgn: p.amount_ngn,
      status: p.status,
      channel: p.channel,
      paidAt: p.paid_at,
      createdAt: p.created_at,
      tenantName: p.tenant_name,
      bookingRef: p.booking_ref,
      checkIn: p.check_in,
      checkOut: p.check_out,
      receiptUrl: p.receipt_url,
      guestFirstName: p.guest_first_name,
      guestLastName: p.guest_last_name,
      guestEmail: p.guest_email,
      roomTypeName: p.room_type_name,
      roomTypeImages: p.room_type_images,
      tenantId: p.tenant_id,
      tenantEmail: p.tenant_email,
    }));
    return { payments, page, limit };
  }
  async getTenantActivity(tenantId: string, page: number, limit: number) {
    const logs = await auditRepository.listByTenant(tenantId, page, limit);
    return { logs, page, limit };
  }
  async listNotifications(page: number, limit: number, tenantId?: string) {
    const rows = await sellerNotificationRepository.listAllForAdmin(
      page,
      limit,
      tenantId,
    );
    const notifications = rows.map((n) => ({
      id: n.id,
      type: n.type,
      title: n.title,
      body: n.body,
      isRead: n.is_read,
      tenantName: n.tenant_name,
      createdAt: n.created_at,
    }));
    return { notifications, page, limit };
  }

  async getPlatformStats() {
    const [
      tenants,
      guests,
      administrators,
      properties,
      bookings,
      volume,
      revenueSplit,
      paymentsCount,
      guestBreakdown,
      propertyBreakdown,
    ] = await Promise.all([
      tenantRepository.countAllByStatus(),
      userRepository.countByType("guest"),
      userRepository.countByType("platform:admin"),
      propertyRepository.countAllForAdmin(),
      bookingRepository.getPlatformStats(),
      paymentRepository.getPlatformVolume(),
      bookingRepository.getRevenueSplitPlatformWide(),
      paymentRepository.countAllForAdmin(),
      userRepository.getGuestBreakdown(),
      propertyRepository.getStatsAllForAdmin(),
    ]);
    return {
      tenants,
      guests,
      administrators,
      properties,
      bookings,
      volume,
      revenueSplit,
      paymentsCount,
      guestBreakdown,
      propertyBreakdown,
    };
  }

  async getRevenueTrend(rangeParam: string) {
    const days =
      { "7-days": 7, "3-weeks": 21, "3-months": 90 }[rangeParam] ?? 7;
    return bookingRepository.getRevenueTrendPlatformWide(days);
  }

  async getCalendar(startDate: string, endDate: string) {
    const rows = await bookingRepository.listForDateRange(startDate, endDate);
    return rows.map((b) => ({
      bookingId: b.id,
      bookingRef: b.booking_ref,
      status: b.status,
      checkIn: b.check_in,
      checkOut: b.check_out,
      guestFirstName: b.guest_first_name,
      guestLastName: b.guest_last_name,
      propertyName: b.property_name,
      roomTypeName: b.room_type_name,
      tenantName: b.tenant_name,
    }));
  }

  async listEscrow(page: number, limit: number, tenantId?: string) {
    const rows = await escrowRepository.listAllForAdmin(page, limit, tenantId);
    const escrows = rows.map((e) => ({
      id: e.id,
      bookingId: e.booking_id,
      status: e.status,
      amountNgn: e.amount_ngn,
      platformFeeNgn: e.platform_fee_ngn,
      hostPayoutNgn: e.host_payout_ngn,
      heldAt: e.held_at,
      releasedAt: e.released_at,
      refundedAt: e.refunded_at,
      bookingRef: e.booking_ref,
      checkIn: e.check_in,
      checkOut: e.check_out,
      tenantName: e.tenant_name,
      tenantEmail: e.tenant_email,
    }));
    return { escrows, page, limit };
  }

  async getEscrowStats() {
    return escrowRepository.getStatsAllForAdmin();
  }

  async getGanttBookingsInRange(from: string, to: string) {
    const rows = await bookingRepository.listForDateRange(from, to);
    return rows.map((b) => ({
      bookingId: b.id,
      bookingRef: b.booking_ref,
      status: b.status,
      guestUserId: b.guest_user_id,
      checkIn: b.check_in,
      checkOut: b.check_out,
      nights: b.nights,
      roomsCount: b.rooms_count,
      guestCount: b.guest_count,
      totalAmountNgn: b.total_amount_ngn,
      platformFeeNgn: b.platform_fee_ngn,
      hostPayoutNgn: b.host_payout_ngn,
      propertyId: b.property_id,
      roomTypeId: b.room_type_id,
      tenantId: b.tenant_id,
      createdAt: b.created_at,
      propertyName: b.property_name,
      roomTypeName: b.room_type_name,
      guestFirstName: b.guest_first_name,
      guestLastName: b.guest_last_name,
      tenant_name: b.tenant_name,
    }));
  }
}

export const adminService = new AdminService();
